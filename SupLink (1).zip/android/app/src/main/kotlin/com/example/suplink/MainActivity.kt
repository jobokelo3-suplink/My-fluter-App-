package com.example.suplink

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
