import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SupLink MMUST',
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  final reg = TextEditingController();
  final pass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF003366),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.school, size: 80, color: Colors.white),
            Text("SupLink MMUST", style: TextStyle(fontSize: 26, color: Colors.white, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  TextField(controller: reg, decoration: InputDecoration(labelText: "Reg Number", border: OutlineInputBorder())),
                  SizedBox(height: 10),
                  TextField(controller: pass, obscureText: true, decoration: InputDecoration(labelText: "Password", border: OutlineInputBorder())),
                  SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 45,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF003366)),
                      onPressed: () {
                        if (reg.text.isEmpty || pass.text.isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Enter Reg No and Correct Password!"), backgroundColor: Colors.red));
                        } else {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => HomePage()));
                        }
                      },
                      child: Text("LOGIN"),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  List<String> titles = ["Supervision", "Missing Marks", "Confirmation", "Transcript", "Consultation"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("SupLink MMUST"), backgroundColor: Color(0xFF003366)),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text(titles[index], style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            TextField(decoration: InputDecoration(labelText: "Reg Number", border: OutlineInputBorder())),
            SizedBox(height: 15),
            TextField(decoration: InputDecoration(labelText: "Details", border: OutlineInputBorder())),
            SizedBox(height: 15),
            TextField(maxLines: 3, decoration: InputDecoration(labelText: "Description", border: OutlineInputBorder())),
            SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 45,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF003366)),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("${titles[index]} Submitted!"), backgroundColor: Colors.green));
                },
                child: Text("SUBMIT"),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (i) => setState(() => index = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Color(0xFF003366),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.people), label: "Supervision"),
          BottomNavigationBarItem(icon: Icon(Icons.warning), label: "Missing"),
          BottomNavigationBarItem(icon: Icon(Icons.check_circle), label: "Confirm"),
          BottomNavigationBarItem(icon: Icon(Icons.description), label: "Transcript"),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: "Consult"),
        ],
      ),
    );
  }
}
